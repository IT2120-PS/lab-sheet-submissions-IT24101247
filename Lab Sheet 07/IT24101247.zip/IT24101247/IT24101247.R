setwd("C:\\Users\\Admin\\OneDrive\\Desktop\\IT24101247")

#1
# Train arrival uniformly distributed between 0 and 40
punif(25, min=0, max=40) - punif(10, min=0, max=40)

#2
pexp(2, rate=1/3)

#3
#i
1 - pnorm(130, mean=100, sd=15)

#ii
qnorm(0.95, mean=100, sd=15)

